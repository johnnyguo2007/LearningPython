# Printing Word Python
# Created by : JohnnyGuo
# Created on 2020-08-17


print(" *****              *       *                             ")
print("*     *             *       *                             ")
print("*     *  *       *  *       *                             ")
print("*     *   *     *   *       *                             ")
print("******     *   *  *****     *  ***     *****    ********* ")
print("*           *       *       *      *  *     *     *      *")
print("*          *        *       *      *  *     *     *      *")
print("*         *         *  *    *      *  *     *     *      *")
print("*      ***           **     *      *   *****      *      *")
