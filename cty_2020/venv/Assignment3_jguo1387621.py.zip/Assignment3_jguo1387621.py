# part A
# We are trying to calculate the average of the three test scores
Test_score_1 = 100
Test_score_2 = 98
Test_score_3 = 93

sum_of_test_scores = Test_score_1 + Test_score_2 + Test_score_3
number_of_tests = 3
avg_of_test_score = sum_of_test_scores/number_of_tests
print("test1: ", Test_score_1, '\t', "test2: ",Test_score_2, '\t', "test3: ", Test_score_3, '\t', "avg: ",avg_of_test_score)

# part B
# Here we are trying to figure out how many euros is 150 US dollars
us_dollar = 150
conversion_rate = 0.81
euro_dollar = us_dollar * conversion_rate
print("euro:", euro_dollar)



